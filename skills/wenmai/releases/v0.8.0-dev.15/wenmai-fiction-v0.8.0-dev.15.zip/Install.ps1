#requires -Version 5.1
<# Install a schema-2 wenmai-offline-release. Never overwrites an existing Skill.
   The manifest inventories every source file; reference names are not fixed.
   The release builder validates source dependencies using transfer_skill.
#>
[CmdletBinding(DefaultParameterSetName = 'Project')]
param(
    [Parameter(Mandatory = $true, ParameterSetName = 'Project')]
    [ValidateNotNullOrEmpty()]
    [string]$ProjectPath,

    [Parameter(Mandatory = $true, ParameterSetName = 'User')]
    [switch]$User,

    [Parameter(ParameterSetName = 'User')]
    [ValidateNotNullOrEmpty()]
    [string]$UserDirectory = [Environment]::GetFolderPath('UserProfile'),

    [Parameter(Mandatory = $true, ParameterSetName = 'Custom')]
    [ValidateNotNullOrEmpty()]
    [string]$SkillsDirectory
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-FullFilesystemPath([string]$Value) {
    return [IO.Path]::GetFullPath($ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Value))
}

function Assert-NoPathLinks([string]$LiteralPath) {
    $currentPath = [IO.Path]::GetFullPath($LiteralPath)
    while ($null -ne $currentPath) {
        if (Test-Path -LiteralPath $currentPath) {
            $item = Get-Item -LiteralPath $currentPath -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw "Path contains a link: $currentPath"
            }
        }
        $parent = [IO.Directory]::GetParent($currentPath)
        $currentPath = if ($null -ne $parent) { $parent.FullName } else { $null }
    }
}

function Get-Sha256([string]$LiteralPath) {
    $algorithm = [Security.Cryptography.SHA256]::Create()
    $stream = $null
    try {
        $stream = [IO.File]::OpenRead($LiteralPath)
        return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-', '').ToLowerInvariant()
    }
    finally {
        if ($null -ne $stream) { $stream.Dispose() }
        $algorithm.Dispose()
    }
}

try {
    $packageRoot = [IO.Path]::GetFullPath($PSScriptRoot)
    Assert-NoPathLinks $packageRoot
    $packagePrefix = $packageRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $skillName = 'longform-fiction'
    $skillPrefix = $skillName + '/'
    $manifestPath = Join-Path $packageRoot 'manifest.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.schema_version -ne 2 -or $manifest.format -cne 'wenmai-offline-release' -or
        $manifest.product -cne 'Wenmai' -or $manifest.skill_name -cne $skillName) {
        throw 'Unsupported Wenmai package manifest.'
    }
    if ($manifest.version -isnot [string] -or
        $manifest.version -cnotmatch '^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$') {
        throw 'Invalid package version.'
    }
    if ($manifest.files -isnot [Array]) { throw 'Manifest files must be an array.' }
    $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $allowedDirectories = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    $entries = @($manifest.files)
    foreach ($entry in $entries) {
        if (@($entry.PSObject.Properties).Count -ne 3 -or
            $entry.path -isnot [string] -or $entry.sha256 -isnot [string] -or
            ($entry.size_bytes -isnot [int] -and $entry.size_bytes -isnot [long]) -or
            $entry.size_bytes -lt 0) {
            throw 'Invalid manifest file entry.'
        }
        $relative = [string]$entry.path
        $parts = $relative.Split('/')
        if ($relative -match '[\\:\x00-\x1f]' -or $parts -contains '' -or
            $parts -contains '..' -or $parts -contains '.' -or
            ($relative -cne 'Install.ps1' -and -not $relative.StartsWith($skillPrefix, [StringComparison]::Ordinal))) {
            throw "Invalid package path: $relative"
        }
        if ($relative -cne 'Install.ps1') {
            $insideSkill = $relative.Substring($skillPrefix.Length)
            # Match the portable directory contract, without listing individual references.
            if ($insideSkill -cnotmatch '^(?:README\.md|SKILL\.md|agents/openai\.yaml|references/[^/]+\.md|scripts/[^./][^/]*\.py)$') {
                throw "Unexpected Skill payload: $relative"
            }
        }
        for ($index = 1; $index -lt $parts.Length; $index++) {
            [void]$allowedDirectories.Add(($parts[0..($index - 1)] -join '/'))
        }
        if (-not $seen.Add($relative)) { throw "Duplicate package path: $relative" }
        $sourcePath = [IO.Path]::GetFullPath((Join-Path $packageRoot $relative))
        if (-not $sourcePath.StartsWith($packagePrefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Path leaves package: $relative"
        }
        if (-not [IO.File]::Exists($sourcePath)) { throw "Missing package file: $relative" }
        $sourceItem = Get-Item -LiteralPath $sourcePath -Force
        if ($sourceItem.PSIsContainer -or ($sourceItem.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw "Expected regular file: $relative"
        }
        if ($entry.sha256 -cnotmatch '^[a-f0-9]{64}$' -or $sourceItem.Length -ne $entry.size_bytes -or
            (Get-Sha256 $sourcePath) -ne $entry.sha256) {
            throw "Package integrity check failed: $relative"
        }
    }
    $required = @('Install.ps1', 'longform-fiction/README.md', 'longform-fiction/SKILL.md',
        'longform-fiction/agents/openai.yaml')
    foreach ($relative in $required) {
        if (-not $seen.Contains($relative)) { throw "Required package file not listed: $relative" }
    }
    foreach ($item in Get-ChildItem -LiteralPath $packageRoot -Recurse -Force) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Package contains a link.' }
        $relative = $item.FullName.Substring($packagePrefix.Length).Replace('\', '/')
        if ($item.PSIsContainer) {
            if (-not $allowedDirectories.Contains($relative)) { throw "Unlisted package directory: $relative" }
        }
        else {
            if ($relative -ne 'manifest.json' -and -not $seen.Contains($relative)) {
                throw "Unlisted package file: $relative"
            }
        }
    }
    $skillText = Get-Content -LiteralPath (Join-Path $packageRoot 'longform-fiction/SKILL.md') -Raw -Encoding UTF8
    $header = [regex]::Match($skillText, '(?s)\A(?:\uFEFF)?---\s*\n(.*?)\n---(?:\s*\n|$)')
    if (-not $header.Success) { throw 'SKILL.md must contain YAML front matter.' }
    $names = [regex]::Matches($header.Groups[1].Value, '(?m)^name:\s*["'']?([\w-]+)["'']?\s*$')
    $versions = [regex]::Matches($header.Groups[1].Value, '(?m)^  version:\s*["'']?([0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?)["'']?\s*$')
    if ($names.Count -ne 1 -or $names[0].Groups[1].Value -cne $skillName -or
        $versions.Count -ne 1 -or $versions[0].Groups[1].Value -cne $manifest.version) {
        throw 'Skill identity or version does not match the manifest.'
    }

    switch ($PSCmdlet.ParameterSetName) {
        'Project' {
            $baseDirectory = Get-FullFilesystemPath $ProjectPath
            if (-not [IO.Directory]::Exists($baseDirectory)) { throw 'ProjectPath must be an existing directory.' }
            $skillsParent = Join-Path $baseDirectory '.agents/skills'
        }
        'User' {
            if (-not $User) { throw 'Specify -User to select personal installation.' }
            $baseDirectory = Get-FullFilesystemPath $UserDirectory
            if (-not [IO.Directory]::Exists($baseDirectory)) { throw 'UserDirectory must be an existing directory.' }
            $skillsParent = Join-Path $baseDirectory '.agents/skills'
        }
        'Custom' { $skillsParent = Get-FullFilesystemPath $SkillsDirectory }
    }
    $target = [IO.Path]::GetFullPath((Join-Path $skillsParent $skillName))
    Assert-NoPathLinks $target
    if (Test-Path -LiteralPath $target) { throw "Already exists; no files changed: $target" }
    if ($target.StartsWith($packagePrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Choose a destination outside the extracted package.'
    }
    [void][IO.Directory]::CreateDirectory($target)
    foreach ($entry in $entries) {
        if (-not $entry.path.StartsWith($skillPrefix, [StringComparison]::Ordinal)) { continue }
        $insideSkill = $entry.path.Substring($skillPrefix.Length)
        $destinationPath = Join-Path $target $insideSkill
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destinationPath))
        [IO.File]::Copy((Join-Path $packageRoot $entry.path), $destinationPath, $false)
        if ((Get-Sha256 $destinationPath) -ne $entry.sha256) {
            throw "Installed file verification failed: $insideSkill"
        }
    }
    Write-Output "Installed Wenmai $($manifest.version): $target"
    Write-Output 'Invoke $longform-fiction in your novel project. If absent, restart Codex.'
}
catch {
    [Console]::Error.WriteLine('Wenmai installation failed: ' + $_.Exception.Message)
    exit 1
}
